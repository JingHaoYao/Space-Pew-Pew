##### What happened?

##### Post-processing stack version (v1, v2)?

##### Unity version, operating system, target platform (standalone windows, mac, iOS, PS4...)?
